<?php

namespace App\Http\Controllers;


use App\Models\Category;
use App\Models\Event;
use App\Models\Order;
use App\Models\Organiser;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function showHomePage()
    {
        $events = Event::where('end_date', '>=', Carbon::now())->where('is_live', true)->where('is_live', true)->orderBy('created_at','desc')->get()->take(12);
        $events_count = Event::all()->count();
        $organisers_count = Organiser::all()->count();
        $orders_count = Order::all()->count();
        $organisers = Organiser::all()->take(6);
        return view('Public.Template.Pages.Home', compact('events','organisers','events_count','organisers_count','orders_count'));
    }

    public function showSearchResults(Request $request)
    {
        if (!$request->get('c'))
        {
            $events = Event::Search($request->get('q'))->where('end_date', '>=', Carbon::now())->where('is_live', true)->orderBy('created_at','desc')->get();
        }
        else
        {
            $events = Event::whereIn('category_id',$request->get('c'))->get();
        }


        $categoris = Category::all();

        return view('Public.Template.Pages.Search', compact('events','categoris','request'));
    }
}
