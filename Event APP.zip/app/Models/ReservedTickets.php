<?php

namespace App\Models;

    /*
      Attendize.com   - Event Management & Ticketing
     */

/**
 * Description of ReservedTickets.
 *
 * @author Dave
 */
class ReservedTickets extends \Illuminate\Database\Eloquent\Model
{
    //put your code here
}
