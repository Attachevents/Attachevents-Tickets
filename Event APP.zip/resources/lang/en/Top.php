<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/25 10:00:32 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
  'account_settings' => 'Account Settings',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
  'create_organiser' => 'Create Organiser',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
  'feedback_bug_report' => 'Feedback / Bug Report',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
  'my_profile' => 'My Profile',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
  'sign_out' => 'Sign Out',
);