<?php

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Widgets.blade.php
  'embed_preview' => 'Embed Preview',
  //==================================== Translations ====================================//
  'event_widgets' => 'Event Widgets',
  'html_embed_code' => 'HTML Embed Code',
  'instructions' => 'Instructions',
  'instructions_text' => 'Simply copy and paste the HTML provided into your website wherever you would like the widget to appear.',
);