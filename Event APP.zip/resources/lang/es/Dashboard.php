<?php

return array(
    'create_tickets'          => 'Crear entradas',
    'edit_event_page_design'  => 'Editar diseño de página de evento',
    'edit_organiser_fees'     => 'Editar las tarifas del organizador',
    'event_page_visits'       => 'Visitas a la página de eventos',
    'event_url'               => 'URL del evento',
    'event_views'             => 'Visitas al evento',
    'generate_affiliate_link' => 'Generar enlace de afiliado',
    'orders'                  => 'Pedidos',
    'quick_links'             => 'Enlaces rápidos',
    'registrations_by_ticket' => 'Inscripciones por entrada',
    'sales_volume'            => 'Volumen de ventas',
    'share_event'             => 'Compartir Evento',
    'this_event_has_started'  => 'Este evento ha comenzado.',
    'this_event_is_on_now'    => 'Este evento ya está en marcha',
    'ticket_sales_volume'     => 'Volumen de venta de entradas',
    'tickets_sold'            => 'Entradas Vendidas',
    'website_embed_code'      => 'Código de incrustación web',
);