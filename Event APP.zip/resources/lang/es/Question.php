<?php

return array(
    'add_another_option'                  => 'Añadir otra opción',
    'answer'                              => 'Respuesta',
    'attendee_details'                    => 'Detalles del asistente',
    'create_question'                     => 'Crear pregunta',
    'make_this_a_required_question'       => 'Convierta esta pregunta en obligatoria',
    'no_answers'                          => 'Lo sentimos, no hay respuestas a esta pregunta todavía.',
    'no_questions_yet'                    => 'No hay preguntas todavía',
    'no_questions_yet_text'               => 'Aquí puede añadir preguntas que les serán preguntadas a los asistentes durante el proceso de compra.',
    'Q'                                   => 'P',
    'question'                            => 'Pregunta',
    'question_options'                    => 'Opciones de las preguntas',
    'question_placeholder'                => 'P.ej.: introduce tu dirección completa.',
    'question_type'                       => 'Tipo de pregunta',
    'require_this_question_for_ticket(s)' => 'Requerir esta pregunta para la(s) entrada(s)',
);