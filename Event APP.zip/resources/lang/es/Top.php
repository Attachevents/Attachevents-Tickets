<?php

return array (
    'account_settings'    => 'Configuración de la cuenta',
    'create_organiser'    => 'Crear Organizador',
    'feedback_bug_report' => 'Comentarios / Informe de errores',
    'my_profile'          => 'Mi Perfil',
    'sign_out'            => 'Cerrar sesión',
);