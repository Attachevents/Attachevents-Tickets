<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:24:53 
*************************************************************************/

return array (
  'service_fee_fixed_price' => 'Prix fixe des frais de service',
  'service_fee_fixed_price_help' => 'par ex. : saisissez <b>1.25</b> pour <b>:cur1.25</b>',
  'service_fee_fixed_price_placeholder' => '0.00',
  'organiser_fees' => 'Frais d\'organisation',
  'organiser_fees_text' => 'Ce sont des frais optionnels que vous pouvez inclure dans le prix de chaque billet.  Cette somme apparaîtra sur les factures de l\'acheteur comme \'<b>BOOKING FEES</b>\'.',
  'service_fee_percentage' => 'Pourcentage de frais de service',
  'service_fee_percentage_help' => 'Par ex. : saisissez <b>3.5</b> pour <b>3.5%</b>',
  'service_fee_percentage_placeholder' => '0',
);
