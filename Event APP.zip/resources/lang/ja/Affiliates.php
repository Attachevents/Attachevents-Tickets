<?php

return array(
    'affiliate_name'             => 'アフィリエイト名',
    'affiliate_tracking'         => 'アフィリエイトトラッキング',
    'affiliate_tracking_text'    => 'あなたのイベントで誰が売り上げを伸ばしているかを追跡することは非常に簡単です。 下のボックスを使用して紹介リンクを作成し、そのリンクをあなたのアフィリエイト/イベントプロモーターと共有するだけです。',
    'last_referral'              => '最後の紹介',
    'no_affiliate_referrals_yet' => 'まだアフィリエイト紹介はありません',
    'sales_volume_generated'     => '販売量',
    'ticket_sales_generated'     => 'チケット販売収益',
    'visits_generated'           => '訪問数',
);