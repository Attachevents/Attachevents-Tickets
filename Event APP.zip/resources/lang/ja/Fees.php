<?php

return array(
    'service_fee_fixed_price'             => 'サービス料固定価格',
    'service_fee_fixed_price_help'        => '例：入力値が <b>100</b> の場合 <b>:cur100</b>',
    'service_fee_fixed_price_placeholder' => '0',
    'organiser_fees'                      => '主催者手数料',
    'organiser_fees_text'                 => 'これらは各チケットの費用に含めることができるオプションの料金です。この料金は、購入者の請求書に<b>予約手数料</b>として表示されます。',
    'service_fee_percentage'              => 'サービス料の割合',
    'service_fee_percentage_help'         => '例：入力値が <b>3.5</b> の場合 <b>3.5%</b>',
    'service_fee_percentage_placeholder'  => '0',
);