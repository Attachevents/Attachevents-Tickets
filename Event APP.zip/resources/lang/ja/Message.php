<?php

return array(
    'new_message'                     => '新着メッセージ',
    'sent_messages'                   => '送信メッセージ',
    'all_event_attendees'             => '全イベント出席者',
    'attendees_with_ticket_type'      => 'チケットタイプの出席者',
    'before_send_message'             => '出席者は:organiserに返信を送るように指示されます。',
    'content'                         => '内容',
    'date'                            => '日付',
    'leave_blank_to_send_immediately' => 'すぐに送信するには空白のままにしてください',
    'message'                         => 'メッセージ',
    'no_messages_for_event'           => 'イベントに関するメッセージはありません。',
    'schedule_send_time'              => 'スケジュール送信時間',
    'send_a_copy_to'                  => 'コピーを:organizerに送ってください',
    'send_message'                    => 'メッセージを送る',
    'send_to'                         => '送信先',
    'subject'                         => '件名',
    'to'                              => 'to',
    'unsent'                          => '未送信',
);