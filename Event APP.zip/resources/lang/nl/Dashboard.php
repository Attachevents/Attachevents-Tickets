<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 18:57:21 
*************************************************************************/

return array (
    //============================== New strings to translate ==============================//
    'this_event_has_started' => 'This event has started.',
    //==================================== Translations ====================================//
    'create_tickets' => 'Creëer tickets',
    'edit_event_page_design' => 'Evenementpagina aanpassen',
    'edit_organiser_fees' => 'Bewerk organisator kosten',
    'event_page_visits' => 'Evenementpagina weergeven',
    'event_url' => 'Evenement URL',
    'event_views' => 'Evenement weergave',
    'generate_affiliate_link' => 'Genereer Volg link',
    'orders' => 'Bestellingen',
    'quick_links' => 'Snelle Links',
    'registrations_by_ticket' => 'Registraties per Ticket',
    'sales_volume' => 'Totale Verkoop',
    'share_event' => 'Deel Evenement',
    'this_event_is_on_now' => 'Dit evenement is nu gaande',
    'ticket_sales_volume' => 'Ticket omzet',
    'tickets_sold' => 'Tickets verkocht',
    'website_embed_code' => 'Website Embed Code',
);