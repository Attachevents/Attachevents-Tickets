<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/26 11:05:24 
*************************************************************************/

return array (
  //==================================== Translations ====================================//
  'attendize_register' => 'Bedankt voor het registreren bij Attendize',
  'invite_user' => ':name toegevoegd aan account :app.',
  'message_regarding_event' => 'Bericht naar aanleiding van: :event',
  'organiser_copy' => '[Organisator kopie]',
  'refund_from_name' => 'U heeft een terugbetaling ontvangen van :name',
  'your_ticket_cancelled' => 'Jou tickets zijn geannuleerd',
  'your_ticket_for_event' => 'Jouw tickets voor het evenement: :event',
    //================================== Obsolete strings ==================================//
  'LLH:obsolete' => 
  array (

  ),
);
