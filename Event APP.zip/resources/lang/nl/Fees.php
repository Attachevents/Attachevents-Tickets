<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:24:53 
*************************************************************************/

return array (
  'service_fee_fixed_price' => 'Servicekosten vaste prijs per ticket',
  'service_fee_fixed_price_help' => 'bv.: vul <b>1.25</b> in, voor <b>:cur1.25</b>',
  'service_fee_fixed_price_placeholder' => '0.00',
  'organiser_fees' => 'Organisator Kosten',
  'organiser_fees_text' => 'Dit zijn optionele ksten en worden op de factuur van de bezoeker apart weergegeven als \'<b>Boekingskosten</b>\'.',
  'service_fee_percentage' => 'Boekingskosten percentage',
  'service_fee_percentage_help' => 'bv.: vul <b>3.5</b> in, voor <b>3.5%</b>',
  'service_fee_percentage_placeholder' => '0',
);