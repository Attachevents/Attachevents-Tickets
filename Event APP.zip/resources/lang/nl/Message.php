<?php

return array (
  'new_message' => 'Nieuw bericht',
  'sent_messages' => 'Verzend berichten',
  'all_event_attendees' => 'Alle bezoekers van dit evenenemet',
  'attendees_with_ticket_type' => 'Alle bezoekers met dit soort ticket',
  'before_send_message' => 'De bezoeker wordt verzocht te reageren via :organiser',
  'content' => 'Inhoud bericht',
  'date' => 'datum',
  'leave_blank_to_send_immediately' => 'Laat leeg om direct te versturen',
  'message' => 'Bericht',
  'no_messages_for_event' => 'Geen berichten voor dit evenenemt.',
  'schedule_send_time' => 'Verzending inplannen op',
  'send_a_copy_to' => 'Verstuur een kopie naar :organiser',
  'send_message' => 'Verstuur bericht',
  'send_to' => 'Verzenden naar',
  'subject' => 'Onderwerp bericht',
  'to' => 'Naar',
  'unsent' => 'Niet verzenden',
);