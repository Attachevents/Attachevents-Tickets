<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/16 08:41:39 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
  'information' => 'Informatie',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
  'tickets' => 'Tickets',
  //==================================== Translations ====================================//
  'no_events' => 'Er zijn geen :panel_title om weer te geven.',
  'organiser_dashboard' => 'Organisator Dashboard',
  'past_events' => 'Afgelopen Evenementen',
  'upcoming_events' => 'Aankomende Evenementen',
);