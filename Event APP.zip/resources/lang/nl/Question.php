<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/18 16:23:42 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Partials\\SurveyBlankSlate.blade.php
  'create_question' => 'Vragenlijst aanmaken',
  //==================================== Translations ====================================//
  'Q' => 'Vraag',
  'add_another_option' => 'Een extra optie toevoegen',
  'answer' => 'Antwoord',
  'attendee_details' => 'Bezoeker details',
  'make_this_a_required_question' => 'Maak deze vraag verplicht',
  'no_answers' => 'Sorry, op deze vraag is nog niet geantwoord.',
  'no_questions_yet' => 'Nog geen vragen',
  'no_questions_yet_text' => 'Hier kunt u vragen configureren die aan uw bezoekers worden gesteld.',
  'question' => 'Vragen',
  'question_options' => 'Vragen Opties',
  'question_placeholder' => 'bv. Wat is uw volledige adres?',
  'question_type' => 'Soort vraag',
  'require_this_question_for_ticket(s)' => 'Deze vraag is noodzakelijk voor ticket(s)',
);