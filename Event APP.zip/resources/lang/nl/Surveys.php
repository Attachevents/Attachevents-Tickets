<?php

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Surveys.blade.php
  'question_delete' => 'Vraag verwijderen',
  //==================================== Translations ====================================//
  'add_question' => 'Vraag toevoegen',
  'answers' => 'Antwoorden',
  'event_surveys' => 'Evenement vragenlijst',
  'export_answers' => 'Exporteren antwoorden',
  'num_responses' => '# Respondenten',
  'question_delete_title' => 'Alle antwoorden worden verwijderd, indien u de antwoorden van de bezoekers wilt bewaren. Kunt u beter de vraag uitschakelen.',
  'question_title' => 'Titel van de vragenlijst',
  'required' => 'Verplicht',
  'status' => 'Status',
  'tickets_list' => 'Tickets: :list',
);