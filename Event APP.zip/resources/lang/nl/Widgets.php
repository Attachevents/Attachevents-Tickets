<?php

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Widgets.blade.php
  'embed_preview' => 'Embed Preview',
  //==================================== Translations ====================================//
  'event_widgets' => 'Evenement Widgets',
  'html_embed_code' => 'HTML Embed Code',
  'instructions' => 'Instructies',
  'instructions_text' => 'Kopieer en plak de HTML code in uw website waar u de widget wil presenteren.',
);