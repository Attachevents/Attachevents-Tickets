<?php

return [
    'back_soon' => 'We zijn binnenkort terug!',
    'back_soon_description'     => 'We zijn momenteel bezig met onderhoud aan onze website.',

];
