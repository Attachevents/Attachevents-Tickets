<?php

return [
    'back_soon' => 'Zaraz wrócimy!',
    'back_soon_description'     => 'Przeprowadzamy ważne zmiany na stronie. Wrócimy później!',

];
