@extends('Public.Template.Layouts.Base')
@section('header')
    @include('Public.Template.Sections.Header')
@endsection
@section('content')

    @include('Public.Template.Sections.Hero')

    @include('Public.Template.Sections.Upcoming')

    @include('Public.Template.Sections.Organisers')

    @include('Public.Template.Sections.Stats')


    <section class="section-sponsors">
        <div class="container">
            <h2 class="text-center mb-10">Our Partners</h2>
            <div class="section-content mt-10">
                <ul class="row">
                    <li class="col-sm-3">
                        <a href="#">
                            <img src="https://oasthousemedia.co.uk/wp-content/uploads/2015/09/your-logo.jpg" alt="image">
                        </a>
                    </li>
                    <li class="col-sm-3">
                        <a href="#">
                            <img src="https://cdn5.f-cdn.com/contestentries/114047/4386384/543c2bfc30d81_thumb900.jpg" alt="image">
                        </a>
                    </li>
                    <li class="col-sm-3">
                        <a href="#">
                            <img src="https://www.macprintblackpool.co.uk/pics/Categories-YourLogo.png" alt="image">
                        </a>
                    </li>
                    <li class="col-sm-3">
                        <a href="#">
                            <img src="http://www.fivefootsix.co.uk/wp-content/uploads/2015/03/Your_Logo_Here-1200x1400.jpg" alt="image">
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <section class="section-newsletter">
        <div class="container">
            <div class="section-content">
                <h2>Stay Up to date With Your Favorite Events!</h2>
                <p>We will sent you some notifications when new event will be create near you.</p>
                <div class="newsletter-form clearfix">
                    <input type="email" placeholder="Your Email Address">
                    <input type="submit" value="Subscribe">
                </div>
            </div>
        </div>
    </section>
@endsection