@extends('Public.Template.Layouts.Base')

@section('header')
    @include('Public.Template.Sections.Header_BG')
@endsection
@section('content')
    <form action="{{route('showSearchResults')}}" method="get">
        <section class="section-refine-search">
            <div class="container">
                <div class="row">

                    <div class="keyword col-sm-6 col-md-8">
                        <label>Search Keyword</label>
                        <input type="text" class="form-control hasclear" name="q" value="{{ $request->get('q') }}" placeholder="Search">
                        <span class="clearer" style="display: none;"><img src="{{ asset('images/clear.png') }}" alt="clear"></span>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <input type="submit" value="Search">
                    </div>
                </div>
            </div>
        </section>
        <section class="section-search-content">
            <div class="container">
                <div class="row">
                    <div id="secondary" class="col-md-4 col-lg-3">
                        <div class="search-filter">
                            <div class="search-filter-category">
                                <h3>Categories</h3>
                                @foreach($categoris as $category)
                                    <div class="checkbox">
                                        <input id="category{{$category->id}}" class="styled" name="c[]" value="{{$category->id}}" type="checkbox" @if($request->get('c')) @if(in_array($category->id,$request->get('c'))) checked @endif @endif>
                                        <label for="category{{$category->id}}">
                                            {{$category->title}}
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                            <section style="padding: 0" class="section-refine-search mt-0">
                                <input style="margin: 0px 0 0;" type="submit" value="Update Search">
                            </section>
                        </div>
                    </div>

                    <div id="primary" class="col-md-8 col-lg-9">
                        @forelse($events as $event)
                            <div class="search-result-item">
                                <div class="row">
                                    <div class="search-result-item-info col-sm-9">
                                        <h3>{{ $event->title }}</h3>
                                        <ul class="row">
                                            <li class="col-sm-5 col-lg-6">
                                                <span>Venue</span>
                                                @if($event->venue_name ==  null) Venue is not available for now @else {{ $event->venue_name }} @endif
                                            </li>
                                            <li class="col-sm-4 col-lg-3">
                                                <span>{{ \Carbon\Carbon::parse($event->start_date)->format('l') }}</span>
                                                {{ \Carbon\Carbon::parse($event->start_date)->format('F. jS, Y') }}
                                            </li>
                                            <li class="col-sm-3">
                                                <span>Time</span>
                                                {{ \Carbon\Carbon::parse($event->start_date)->format('h:i A') }}
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="search-result-item-price col-sm-3">
                                        <span>Price From</span>
                                        @if($event->tickets()->orderBy('price')->first() == null) <span>Tickets are currently unavailable</span> @else<strong> @if($event->tickets()->orderBy('price')->first()->price == 0) Free @else ${{ $event->tickets()->orderBy('price')->first()->price }} @endif @endif</strong>
                                        <a href="{{ route('showEventPage',$event) }}">Book Now</a>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="search-result-item">
                                <div class="row">
                                    <div class="search-result-item-info col-sm-12 text-center">
                                        <h3>Search result is empty for "{{ $request->get('q') }}"<br><br>Please try with Event Title, Venue Name or Location</h3>
                                    </div>
                                </div>
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </section>
    </form>
@endsection