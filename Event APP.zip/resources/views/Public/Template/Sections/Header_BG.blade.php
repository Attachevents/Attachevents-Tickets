<header id="masthead" class="site-header">
    <div class="top-header top-header-bg">
        <div class="container">
            <div class="row">
                <div class="top-left">
                    <ul>
                        <li>
                            <a href="#">
                                <i class="fa fa-phone"></i>
                                +62274 889767
                            </a>
                        </li>
                        <li>
                            <a href="mailto:hello@myticket.com">
                                <i class="fa fa-envelope-o"></i>
                                support@website.com
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="top-right">
                    <ul>
                        @guest
                            <li>
                                <a href="{{ route('login') }}">Sign In</a>
                            </li>
                            <li>
                                <a href="{{ route('showSignup') }}">Sign Up</a>
                            </li>
                        @endguest

                        @auth
                            <li>
                                <a href="{{ route('showSelectOrganiser') }}">My Event</a>
                            </li>
                            <li>
                                <a href="{{ route('login') }}">Welcome {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}</a>
                            </li>
                        @endauth

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="main-header top-header top-header-bg">
        <div class="container">
            <div class="row">
                <div class="site-branding col-md-3">
                    <h1 class="site-title"><a href="{{ route('showHomePage') }}" title="" rel="home"><img style="max-height: 63px" src="images/logo.png" alt="logo"></a></h1>
                </div>

                <div class="col-md-9">
                    <nav id="site-navigation" class="navbar">
                        <div class="navbar-header">
                            <div class="mobile-cart" ><a href="#">0</a></div>
                            <button type="button" class="navbar-toggle offcanvas-toggle pull-right" data-toggle="offcanvas" data-target="#js-bootstrap-offcanvas">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-offcanvas navbar-offcanvas-touch navbar-offcanvas-right" id="js-bootstrap-offcanvas">
                            <button type="button" class="offcanvas-toggle closecanvas" data-toggle="offcanvas" data-target="#js-bootstrap-offcanvas">
                                <i class="fa fa-times fa-2x" aria-hidden="true"></i>
                            </button>
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="event-by-category.html">Support</a></li>
                                <li><a href="gallery.html">About Us</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>