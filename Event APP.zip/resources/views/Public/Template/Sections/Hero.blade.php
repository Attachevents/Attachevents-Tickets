<section class="hero-1">
    <div class="container">
        <div class="row">
            <div class="hero-content">
                <h1 class="hero-title">Book, Sell your event tickets </h1>
                <p class="hero-caption">Create events for your organiser and sell tickets</p>
                <div class="hero-search">
                    <form action="{{ route('showSearchResults') }}">
                        <input type="text" name="q" placeholder="Search Event Name or Venue">
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>