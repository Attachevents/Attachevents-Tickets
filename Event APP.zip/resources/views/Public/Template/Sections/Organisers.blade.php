<section class="section-event-category">
    <div class="container">
        <div class="row">
            <div class="section-header">
                <h2>Organisers</h2>
            </div>
            <div class="section-content">
                <ul class="row clearfix">
                    @foreach($organisers as $organiser)
                        <li class="category-1 col-sm-4">
                            <img src="{{ $organiser->logo_path }}" alt="image">
                            <a href="{{ route('showOrganiserHome',$organiser) }}"><span>{{ $organiser->name }}</span></a>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</section>