<section class="section-stats">
    <div class="container">
        <div class="row">
            <div class="section-content">
                <ul class="row clearfix">
                    <li class="col-sm-4">
                        <span class="count">{{ $events_count }}</span>
                        <hr>
                        <p>Events Active</p>
                    </li>
                    <li class="col-sm-4">
                        <span class="count">{{ $organisers_count }}</span>
                        <hr>
                        <p>Organisers</p>
                    </li>
                    <li class="col-sm-4">
                        <span class="count">{{ $orders_count }}</span>
                        <hr>
                        <p>Ticket Sold</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>