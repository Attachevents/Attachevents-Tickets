<section class="section-upcoming-events">
    <div class="container">
        <div class="row">
            <div class="section-header">
                <h2>Upcoming Events</h2>
                <p>Select your event from upcoming list and book it now</p>
                <a href="{{ route('showSearchResults') }}">See all upcoming events</a>
            </div>
            <div class="section-content">
                <ul class="clearfix">
                    @foreach($events as $event)
                        <li style="margin-right: 10px;">
                            <div class="date">
                                <a href="{{ route('showEventPage',$event) }}">
                                    <span class="day">{{ \Carbon\Carbon::parse($event->start_date)->format('d') }}</span>
                                    <span class="month">{{ \Carbon\Carbon::parse($event->start_date)->format('M') }}</span>
                                    <span class="year">{{ \Carbon\Carbon::parse($event->start_date)->format('Y') }}</span>
                                </a>
                            </div>
                            <a href="{{ route('showEventPage',$event) }}">
                                <img src="@if($event->images->first() == null) http://togetherasonefoundation.org/wp-content/uploads/2019/01/EVENTS.png @else {{ $event->images->first()->image_path }} @endif" alt="image">
                            </a>
                            <div class="info">
                                <p>
                                    {{ $event->title }}
                                    <span>at @if($event->location_address) {{ $event->location_address }} @elseif($event->location_address_line_1) {{ $event->location_address_line_1 }} @elseif($event->location_address_line_1) @elseif($event->location_address_line_2) {{ $event->location_address_line_2 }} @elseif($event->location_country) {{ $event->location_country }} @elseif($event->location_state) {{ $event->location_state }} @elseif($event->venue_name) {{ $event->venue_name }} @endif</span>
                                    <span>{{ $event->category->title }}</span>
                                </p>
                                <a href="{{ route('showEventPage',$event) }}" class="get-ticket">Get Ticket</a>
                            </div>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</section>