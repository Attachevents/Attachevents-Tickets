
            <div class="fb-page" data-href="https://www.facebook.com/{{$facebook_account}}"
                 data-tabs="timeline" data-small-header="false"
                 data-adapt-container-width="true"
                 data-with="100%"
                 data-hide-cover="false" data-show-facepile="true">
                <div class="fb-xfbml-parse-ignore">
                    <blockquote cite="https://www.facebook.com/facebook">
                        <a href="https://www.facebook.com/{{$facebook_account}}">Facebook</a>
                    </blockquote>
                </div>
            </div>
