<pre>
    {{json_encode($data)}}
</pre>
<hr>
<pre>
    {{json_encode($job)}}
</pre>

